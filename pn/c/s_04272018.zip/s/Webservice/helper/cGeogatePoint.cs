﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Webservice.helper
{
    public class cGeogatePoint
    {
        public double lat;
        public double lon;

    public cGeogatePoint(double dlat, double dlon)
    {
        lat = dlat;
        lon = dlon;
    }
}

}